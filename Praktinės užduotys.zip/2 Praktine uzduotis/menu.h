//
// Created by Evuliuks on 2022-01-20.
//

#ifndef INC_2_PRAKTINE_UZDUOTIS_MENU_H
#define INC_2_PRAKTINE_UZDUOTIS_MENU_H

#endif //INC_2_PRAKTINE_UZDUOTIS_MENU_H
void mainMenu(int &option) {
    cout << "\nPasirinkite paslauga: " << endl;
    cout << "1. Storage" << endl;
    cout << "2. Serveris" << endl;
    cout << "3. Duomenų Bazė" << endl;
    cout << "4. Kliento užakytos paslaugos/ plano keitimas" << endl;
    cout << "5. Exit" << endl;
    cout << "\nPasirinkite vieną skaičiu iš aukščiau pateiktų: " << endl;
    cin >> option;
}

void storageMenu(int &option, int &storage, int &manoStorageplanas, int &storageUserInput) {
    cout << "\nSTORAGE laisvos vietos liko: " << storage << " TB" << endl;
    cout << "Mano storage planas: " << manoStorageplanas << " TB" << endl;

    cout << "\nPasirinkti STORAGE plana:" << endl;
    cout << "1. 10TB" << endl;
    cout << "2. 100TB" << endl;
    cout << "3. Pagal Poreikį" << endl;
    cout << "4. Grižti į pradžią" << endl;
    cout << "\nPasirinkite vieną skaičiu iš aukščiau pateiktų:" << endl;
    cin >> option;

    if(manoStorageplanas == 0) {
        if (option == 1) {
            storage -= 10;
            manoStorageplanas = 10;
        } else if (option == 2) {
            storage -= 100;
            manoStorageplanas = 100;
        } else if (option == 3) {
            cout << "\nĮveskite norima duomenų kiekio skaičių (TB):" << endl;
            cin >> storageUserInput;
            cout << "Jus ivedete: " << storageUserInput << endl;

            storage -= storageUserInput;
            manoStorageplanas = storageUserInput;
        } else {
            cout << "Grįžtama atgal" << endl;
        }
    } else {
        cout << "Planas jau yra pasirinktas." << endl;
    }
}

void serversMenu(int &option, std::string &serversPlan) {
    serversPlan.empty() ? cout << "\nDabartinis SERVERS planas: Nera\n" : cout << "\nDabartinis SERVERS planas:" << serversPlan << endl;

    cout << "\nPasirinkite SERVERS planą: " << endl;
    cout << "1. BASIC" << endl;
    cout << "2. MIDDLE" << endl;
    cout << "3. MAX" << endl;
    cout << "4. Grižti į pradžią" << endl;
    cout << "\nPasirinkite vieną skaičių iš aukščiau pateiktų:" << endl;
    cin >> option;

    if(serversPlan.empty()) {
        if(option == 1) serversPlan = "BASIC";
        else if (option == 2) serversPlan = "MIDDLE";
        else if (option == 3) serversPlan = "MAX";
        else if (option == 4) cout << "Grįžtama atgal" << endl;
    } else {
        cout << "Planas jau yra pasirinktas." << endl;
    }
}

void dbMenu(int &option, int &db, int &manoDuomenuBazesplanas, int &dbUserInput) {
    cout << "\nDATABASE laisvos vietos liko: " << db << " GB" << endl;
    cout << "Mano duomenų bazės planas: " << manoDuomenuBazesplanas << " GB" << endl;

    cout << "\nPasirinkti DATABASE planą:" << endl;
    cout << "1. 1GB" << endl;
    cout << "2. 10GB" << endl;
    cout << "3. Pasgal Poreikį" << endl;
    cout << "4. Grįžti į pradžią" << endl;
    cout << "\nPasirinkite vieną skaičių iš aukščiau peteiktų:" << endl;
    cin >> option;

    if(manoDuomenuBazesplanas == 0) {
        if (option == 1) {
            db -= 1;
            manoDuomenuBazesplanas = 1;
        } else if (option == 2) {
            db -= 10;
            manoDuomenuBazesplanas = 10;
        } else if (option == 3) {
            cout << "\nĮveskite norimą duomenų kiekio skaičių (GB):" << endl;
            cin >> dbUserInput;
            cout << "Jūs įvedėte: " << dbUserInput << endl;

            db -= dbUserInput;

            manoDuomenuBazesplanas = dbUserInput;
        } else {
            cout << "Grįžtama atgal" << endl;
        }
    } else {
        cout << "Planas jau yra pasirinktas." << endl;
    }
}

void changeMenu(int &option, int &defaultStorage, int &defaultDb, int &storage, int &db, string &serversPlan, int &manoStorageplanas, int &manoDuomenuBaze, int &storageUserInput, int &dbUserInput) {
    cout << "\nGaliojančios paslaugos yra: " << endl;

    cout << "\nStorage: " << defaultStorage - storage << " TB" << endl;

    serversPlan.empty() ? cout << "Dabartinis SERVERS planas: Nera\n" : cout << "Dabartinis SERVERS planas:" << serversPlan << endl;

    cout << "Database: " << defaultDb - db << " GB" << endl;

    cout << "\n1. Keisti" << endl;
    cout << "2. Grįžti" << endl;

    cout << "\nPasirinkite vieną skaičių iš aukščiau pateiktų: " << endl;
    cin >> option;

    if(option == 1) {
        int changeOption;

        cout << "\nPasirinkite paslauga kurią norite keisti: " << endl;
        cout << "1. Storage" << endl;
        cout << "2. Serveris" << endl;
        cout << "3. Duomenų Bazė" << endl;
        cout << "5. Exit" << endl;
        cout << "\nPasirinkite viena skaičių iš aukščiau pateiktų: " << endl;
        cin >> changeOption;

        int select;
        if(changeOption == 1) {
            cout << "Naujas Storage Planas: " << endl;
            storage += manoStorageplanas;
            manoStorageplanas = 0;

            cout << "\nPasirinkite STORAGE planą:" << endl;
            cout << "1. 10TB" << endl;
            cout << "2. 100TB" << endl;
            cout << "3. Pasirinktinai" << endl;
            cin >> select;

            if(select == 1) {
                storage -= 10;
                manoStorageplanas = 10;
            } else if (select == 2) {
                storage -= 100;
                manoStorageplanas = 100;
            } else {
                cout << "\nĮveskite norimą duomenų kiekio skaičių (TB):" << endl;
                cin >> storageUserInput;
                cout << "Jūs įvedėte: " << storageUserInput << endl;

                storage -= storageUserInput;
                manoStorageplanas = storageUserInput;
            }
        } else if (changeOption == 2) {
            cout << "\nKeisti SERVERS planą: " << endl;
            cout << "1. BASIC" << endl;
            cout << "2. MIDDLE" << endl;
            cout << "3. MAX" << endl;
            cout << "\nPasirinkite vieną skaičių iš aukščiau pateiktų:" << endl;
            cin >> select;

            if (select == 1) serversPlan = "BASIC";
            else if (select == 2) serversPlan = "MIDDLE";
            else if (select == 3) serversPlan = "MAX";

        } else if (changeOption == 3) {
            cout << "\nKeisti DATABASE planą:" << endl;

            db += manoDuomenuBaze;
            manoDuomenuBaze = 0;

            cout << "1. 1GB" << endl;
            cout << "2. 10GB" << endl;
            cout << "3. Pagal poreikį" << endl;
            cout << "\nPasirinkite vieną skaičių iš aukščiau pateiktų:" << endl;
            cin >> select;

            if(select == 1) {
                db -= 1;
                manoDuomenuBaze = 1;
            } else if (select == 2) {
                db -= 10;
                manoDuomenuBaze = 10;
            } else {
                cout << "\nĮveskite norimą duomenų kiekio skaičių (GB):" << endl;
                cin >> dbUserInput;
                cout << "Jūs įvedėte: " << dbUserInput << endl;

                db -= dbUserInput;
                manoDuomenuBaze = dbUserInput;
            }
        } else {
            cout << "Grįžtama atgal" << endl;
        }
    } else {
        cout << "Grįžtama atgal" << endl;
    }
}