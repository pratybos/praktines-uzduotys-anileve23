#include <iostream>
#include <vector>
#include <string>
using namespace std;
#include "menu.h"
int main() {
    int defaultStorage = 5000, defaultDb = 10000;
    int *storage = new int(5000);
    int *db = new int(10000);
    int option = 0, storageUserInput = 0, dbUserInput = 0;
    string serversPlan;
    int manoStorageplanas = 0, manoDuomenuBazesplanas= 0;

    int switcher = 1;

    while (switcher) {
        mainMenu(option);
        switch (option) {
            case 1:
                storageMenu(option, *storage, manoStorageplanas, storageUserInput);
                break;
            case 2:
                serversMenu(option, serversPlan);
                break;
            case 3:
                dbMenu(option, *db, manoDuomenuBazesplanas, dbUserInput);
                break;
            case 4:
                changeMenu(option, defaultStorage, defaultDb, *storage, *db, serversPlan, manoStorageplanas, manoDuomenuBazesplanas, storageUserInput, dbUserInput);
                break;
            default:
                switcher = 0;
        }
    }
    return 0;
}
